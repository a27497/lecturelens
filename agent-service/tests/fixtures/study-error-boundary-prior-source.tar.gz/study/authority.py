import hashlib
import hmac
import ipaddress
import json
import os
import time
from urllib.parse import urlsplit

import httpx

from .learning_scope import check_scope_response, inject_scope
from .store import StudyError

AUDIENCE = "lecturelens-study-v1"
AUTHORITY_PATH = "/internal/v1/study/evidence"
SCOPED_AUTHORITY_PATH = "/internal/v1/study/scoped-evidence"
COMMAND_PATH = "/internal/v1/study/command"


def signature(secret, timestamp, body, path):
    message = f"{AUDIENCE}\nPOST\n{path}\n{timestamp}\n{hashlib.sha256(body).hexdigest()}"
    return hmac.new(secret.encode(), message.encode(), hashlib.sha256).hexdigest()


def request_body(payload):
    # Stable bytes let MCP forward the Agent's signature without holding its key.
    return json.dumps(payload, ensure_ascii=False, sort_keys=True).encode()


def authority_path(payload):
    # A legacy authority must reject the route before parsing away a scope field.
    return SCOPED_AUTHORITY_PATH if payload.get("learning_scope") is not None else AUTHORITY_PATH


def forward_signed(url, payload, timestamp, signed):
    """Same Java endpoint and scope check for direct and MCP transports."""
    with httpx.Client(timeout=10, follow_redirects=False, trust_env=False) as client:
        response = client.post(
            url.rstrip("/") + authority_path(payload),
            content=request_body(payload),
            headers={
                "Content-Type": "application/json",
                "X-LectureLens-Timestamp": timestamp,
                "X-LectureLens-Signature": signed,
            },
        )
    if response.status_code in (401, 403, 404, 409):
        raise StudyError("COURSE_UNAVAILABLE_OR_CHANGED")
    response.raise_for_status()
    result = response.json()["data"]
    if any(result.get(k) != payload[k] for k in ("owner_id", "course_id", "revision")):
        raise StudyError("EVIDENCE_SCOPE_MISMATCH")
    check_scope_response(payload, result)
    return result


class EvidenceAuthority:
    def __init__(self, url, secret):
        parsed = urlsplit(url)
        try:
            address = ipaddress.ip_address(parsed.hostname or "")
        except ValueError:
            address = None
        local_http = parsed.hostname == "localhost" or address == ipaddress.ip_address("127.0.0.1")
        tailscale_http = address is not None and address in ipaddress.ip_network("100.64.0.0/10")
        if (
            parsed.scheme not in {"http", "https"}
            or not parsed.hostname
            or parsed.username
            or parsed.password
            or parsed.path not in {"", "/"}
            or parsed.query
            or parsed.fragment
            or (parsed.scheme == "http" and (not parsed.port or not (local_http or tailscale_http)))
        ):
            raise RuntimeError("Invalid AGENT_JAVA_BASE_URL")
        self.url, self.secret = url.rstrip("/"), secret

    def read(self, scope, action="CHECK", **arguments):
        payload = {
            "owner_id": scope["owner_id"],
            "course_id": scope["course_id"],
            "revision": scope["revision"],
            "action": action,
            **arguments,
        }
        payload = inject_scope(scope, payload)
        body = request_body(payload)
        timestamp = str(int(time.time()))
        return forward_signed(
            self.url, payload, timestamp, signature(self.secret, timestamp, body, authority_path(payload))
        )


def course_authority(url, secret):
    transport = os.environ.get("AGENT_COURSE_TOOL_TRANSPORT", "internal")
    if transport == "internal":
        return EvidenceAuthority(url, secret)
    if transport == "mcp":
        from ..course_mcp.client import McpEvidenceAuthority

        return McpEvidenceAuthority(url, secret)
    raise RuntimeError("AGENT_COURSE_TOOL_TRANSPORT must be internal or mcp")
